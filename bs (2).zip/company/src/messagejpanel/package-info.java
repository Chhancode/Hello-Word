/**
 * 
 */
/**
 * @author jenny
 *
 */
package messagejpanel;